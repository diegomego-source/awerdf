module.exports = {
        accountName: 'bot10510',
        password: 'Pamer8148',
        shared_secret: '0dDtY0dhs3YLxMkMxtuKmmySWrI=',
        botName: 'Snow♥ Bot [24/7]',
        identitySecret: 'cggF5OTKQ4kbhrPyHsbgKBU9/0s=',
        arr_idBossAccount: ["79428243459"], // array of steamID64 that bot will accept offer 
        accept_gifted: true, // true for accept gifted items - false for not accept them
        trash_defindex: [5875,5893], //Defindex of items that bot will delete
        min_Reclaimeds: 2, // Number of reclaimeds that always need to exists in backpack
        min_Scraps:2,// Number of scraps that always need to exists in backpack
  };
